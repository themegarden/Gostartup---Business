Go is Tailwind CSS business website template specially crafted for - business, agency, corporate and startup websites. This Tailwind Business template comes with all essential sections and pages you need to launch a complete business and corporate website in a few minutes.

Business website sections that includes - a cool hero area, a features section with icons, an about section (tabs), a team section, blog grids, a contact section, testimonials, clients, and more.

Pages include - stunning homepage, contact, login register, blog, 404, and more.

If you are looking for a high-quality website template for business and startup based on Tailwind CSS, Go will be the perfect choice for you!